A=[2 2 8 7 9 6;4 6 9 80 5 6;3 95 2 4 5 25;1 3 7 5 13 15;5 10 15 20 25 30;9 18 27 36 45 54] 

sin(A)

C=[max(A);max(A,[],2)']
%the first row of C denotes the maximum of each column of A
%the second row of C denotes the maximum of each row of A

[M,I] = max(A(:))%largest element
[row,col] = ind2sub(size(A),I)%row and column of largest element

A(:,1:3)=sort(A(:,1:3),'descend')

B=cumsum(A)

A(1,1)=A(1,1)+5

X=[A(:,5);A(:,2)]




